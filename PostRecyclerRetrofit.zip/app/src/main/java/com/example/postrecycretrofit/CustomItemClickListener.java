package com.example.postrecycretrofit;


public interface CustomItemClickListener {
    public void onItemClick(User user, int position);
}
